//Modify this file to change what commands output to your statusbar, and recompile using the make command.
static const Block blocks[] = {
	/*Icon*/	/*Command*/		/*Update Interval*/	/*Update Signal*/
	
	{"^c#FFFF00^   ^c#FF99CC^", "~/dwmblocks/mail",	300,		0},
	{"^c#99CCFF^   ^c#FFFFFF^", "~/dwmblocks/cpu",	2,		0},
	{"^c#99FFCC^   ^c#99FFFF^", "~/dwmblocks/weather",	300,		0},
	{"^c#CCFF99^   ^c#99FFCC^", "echo $(curl wttr.in/Caerphilly?format='%l+%C+%f' 2>/dev/null)",	200,		0},
	{"^c#FF9999^   ^c#99CCFF^", "free -h | awk '/^Mem/ { print $3\"/\"$2 }' | sed s/i//g",	2,		0},
{"^c#FFFFFF^   ^c#FF9999^", "date +'%d-%m-%Y'",	300,		0},
	{"^c#FFFF00^  ^c#99FF99^", "date +'%H:%M:%S'",					3,		0},
};

//sets delimeter between status commands. NULL character ('\0') means no delimeter.
static char delim[] = " | ";
static unsigned int delimLen = 5;
