/* See LICENSE file for copyright and license details. */
#include <stdio.h>

#include "../util.h"

const char *
separator(const char *separator)
{
    return separator;
}
