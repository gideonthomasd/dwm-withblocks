#!/bin/bash
set -e

yay -S --noconfirm nerd-fonts-mononoki
